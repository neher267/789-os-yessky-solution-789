<P>
	<strong>
		Dear {{$name}}, 
	</strong>
</P>

<p>{{$body}}</p>

<P>
	<strong>
		Sky Solution Ltd
	</strong>
</P>

<p>Dhaka, Bangladesh</p>
<p>Phone: +88038474</p>