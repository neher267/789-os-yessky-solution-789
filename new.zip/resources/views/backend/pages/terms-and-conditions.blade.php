@extends('backend.master')

@section('content')
<!-- BEGIN CONTENT BODY -->
<div class="page-content">
    <iframe src="{{asset('TERMS-AND-CONDITIONS-SSPCL.pdf')}}" style="width: 100%; height: 1000px;"></iframe>    
</div>
<!-- END CONTENT BODY -->
@endsection