<div class="row">
    <div class="col-md-9"></div>
    <div class="col-md-3">

        <form id="w0" action="search" method="get">
            <div class="form-group">
                <div class="input-icon">
                    <i class="fa fa-search"></i>
                    <input type="text" class="tooltipped form-control input-circle tooltips" data-toggle="tooltip" title="" placeholder="Search" name="term" value="" autocomplete="off" data-html="true" data-original-title="Search by TG No. / Name of Operator / Aircraft Registration / Callsign / Permit Number" data-placement="bottom">
                </div>
            </div>

        </form>

    </div>
</div>